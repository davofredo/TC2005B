public interface EnvioMensaje {
    void enviarMensaje(Object object);
}
