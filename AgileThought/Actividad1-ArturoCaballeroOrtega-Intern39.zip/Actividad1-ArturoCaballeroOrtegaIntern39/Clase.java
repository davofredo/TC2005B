public class Clase {
    public static void main(String[] args) {
        System.out.println("Holaaaa, que tengas un buen dia");    
    }
}