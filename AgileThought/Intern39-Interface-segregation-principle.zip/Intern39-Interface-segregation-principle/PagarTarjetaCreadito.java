public interface PagarTarjetaCreadito extends PagosServices {
    void pagarTarjetaCreadito();
}
