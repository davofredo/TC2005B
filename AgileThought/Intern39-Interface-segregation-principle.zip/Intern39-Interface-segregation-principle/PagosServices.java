public interface PagosServices {
    void calculaPago();
    void transferenciaBancaria();
}
