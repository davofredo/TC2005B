public interface TransferirBancaria extends PagosServices {
    void transferirBancaria();
}
