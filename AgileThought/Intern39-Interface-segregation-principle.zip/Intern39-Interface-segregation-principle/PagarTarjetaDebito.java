public interface PagarTarjetaDebito extends PagosServices {
    void pagarTarjetaDebito();
}
