public class Visa implements PagarTarjetaDebito {

    @Override
    public void pagarTarjetaDebito() {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void calculaPago() {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void transferenciaBancaria() {
        // TODO Auto-generated method stub
        
    }
    
}
