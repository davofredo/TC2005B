public class Amex implements PagarTarjetaCreadito {

    @Override
    public void pagarTarjetaCreadito() {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void calculaPago() {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void transferenciaBancaria() {
        // TODO Auto-generated method stub
        
    }
    
}
