public class ObjetoCercano {
    private ObjetoJuego objeto;
    private int distancia;

    public ObjetoJuego getObjeto() {
        return objeto;
    }

    public int getDistancia() {
        return distancia;
    }
}
