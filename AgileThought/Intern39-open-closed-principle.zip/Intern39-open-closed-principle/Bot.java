public class Bot extends ObjetoJuego {

    public Bot(int velocidad, int rangoVision, boolean controlado, int salud, int posX, int posY) {
        super(velocidad, rangoVision, controlado, salud, posX, posY);
    }
}
